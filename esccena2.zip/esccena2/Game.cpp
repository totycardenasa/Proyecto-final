#include "Game.h"
#include <QTimer>
#include <QGraphicsTextItem>
#include <QFont>
#include "Enemy.h"
#include "Player.h"
#include "Score.h"
#include "Health.h"

Game::Game(QWidget *parent) : QGraphicsScene(0, 0, 1364, 766, parent) {
    // Create the player
    player = new Player(this);
    player->setRect(0, 0, 100, 100); // change the rect from 0x0 (default) to 100x100 pixels
    player->setPos(400, 500); // TODO generalize to always be in the middle bottom of screen
    // Make the player focusable and set it to be the current focus
    player->setFlag(QGraphicsItem::ItemIsFocusable);
    player->setFocus();
    // Add the player to the scene
    addItem(player);

    // Create the score and health
    score = new Score();
    addItem(score);
    health = new Health();
    health->setPos(health->x(), health->y() + 25);
    addItem(health);

    // Spawn enemies
    QTimer *timer = new QTimer();
    QObject::connect(timer, SIGNAL(timeout()), player, SLOT(spawn()));
    timer->start(2000);
}
