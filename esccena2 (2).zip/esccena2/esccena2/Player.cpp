#include "Player.h"
#include "Bullet.h"
#include "Enemy.h"

Player::Player(Game *game, QGraphicsItem *parent)
    : QObject(), QGraphicsPixmapItem(parent), game(game) {
    // Set player properties (e.g., size, position) here if needed
    setPixmap(QPixmap(":/images/uuee.png"));
    setPos(0, 0); // Position at the top-left corner
    setScale(0.5);

    // Make the player focusable and set it to be the current focus
    setFlag(QGraphicsItem::ItemIsFocusable);
    setFocus();

    // Initialize and start the timer
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Player::updatePosition);
    timer->start(50); // Update every 50 ms
}

void Player::keyPressEvent(QKeyEvent *event) {
    keysPressed.insert(event->key());

    if (event->key() == Qt::Key_Space) {
        // Create a bullet
        Bullet *bullet = new Bullet(game);
        bullet->setPos(100, y() + pixmap().height() / 2); // Position the bullet at x=100 and y=center of the player
        scene()->addItem(bullet);
    }
}

void Player::keyReleaseEvent(QKeyEvent *event) {
    keysPressed.remove(event->key());
}

void Player::updatePosition() {
    if (keysPressed.contains(Qt::Key_W) && pos().y() > 0) {
        setPos(x(), y() - 10);
    }
    if (keysPressed.contains(Qt::Key_S) && pos().y() + pixmap().height() < 760) {
        setPos(x(), y() + 10);
    }
}

void Player::spawn() {
    // Create an enemy
    Enemy *enemy = new Enemy(game);
    scene()->addItem(enemy);
}
