#ifndef PLAYER_H
#define PLAYER_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QKeyEvent>
#include <QSet>
#include <QTimer>

// Declaración anticipada de la clase Game
class Game;

class Player : public QObject, public QGraphicsPixmapItem {
    Q_OBJECT
public:
    Player(Game *game, QGraphicsItem *parent = nullptr);
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
public slots:
    void spawn();
    void updatePosition(); // Añadido
private:
    Game *game;
    QSet<int> keysPressed; // Añadido para almacenar las teclas presionadas
    QTimer *timer; // Añadido
};

#endif // PLAYER_H
