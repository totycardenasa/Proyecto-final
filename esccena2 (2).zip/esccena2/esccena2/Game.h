#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "Player.h"
#include "Score.h"
#include "Health.h"

class Game : public QGraphicsScene {
    Q_OBJECT
public:
    Game(QWidget *parent = nullptr);

    Player *player;
    Score *score;
    Health *health;
};

#endif // GAME_H
